extends Node2D

const CELL := 52
const W := 36
const H := 25
const HEROES := [
 {"name":"Артём", "class":"Инженер-штурмовик", "color":Color("e7a951"),"max_hp":150,"power":22,"skill":"Удар молотом"},
 {"name":"Лиза", "class":"Биохимик", "color":Color("8de1bc"),"max_hp":105,"power":17,"skill":"Биоимпульс"},
 {"name":"Жека", "class":"Бронированный стрелок", "color":Color("9db4ef"),"max_hp":180,"power":26,"skill":"Шквальный огонь"},
 {"name":"Володя", "class":"Мафиозный дипломат", "color":Color("d6a7e9"),"max_hp":120,"power":20,"skill":"Теневой контракт"}
]
const BIO := [
 "АРТЁМ. Бывший вахтовик. После белковой реформы проснулся с хитиновыми руками. Теперь считает каждую смену частью великой стройки Улья.",
 "ЛИЗА. Учёная, которая первой поняла механизм метаморфозы. Её формулы спасают отряд, хотя никто не понимает её почерк.",
 "ЖЕКА. Выжил в пепельных пустошах. Сросся с экспериментальной бронёй. Отказывается признавать, что его пулемёт — семейная реликвия.",
 "ВОЛОДЯ. До превращения торговал всем, кроме совести. Теперь заключает контракты между колониями и получает комиссию даже за апокалипсис."
]
var rng := RandomNumberGenerator.new()
var tiles := []
var enemies := []
var loot := []
var player := Vector2i(5,5)
var hero := 0
var levels := [1,1,1,1]
var xp := [0,0,0,0]
var hp := [150,105,180,120]
var points := [0,0,0,0]
var power_bonus := [0,0,0,0]
var credits := 40
var medkits := 3
var kills := 0
var quest := 0
var log_text := "Шваб ожидает доклад. Найдите его у центрального терминала."
var camera_pos := Vector2.ZERO
var ui : CanvasLayer
var panel : PanelContainer
var labels := {}
var cooldown := 0.0
var paused_dialog := false
var flash := 0.0
var visual_player := Vector2(5,5)
var walk_clock := 0.0
const FIELD_WIDTH := 890
const SKILLS := [
 [["Стальная смена", "+7 урона молотом"],["Бригадир", "+25 максимального здоровья"],["Вахта без сна", "+10 урона и 10 здоровья"]],
 [["Мутаген", "+7 урона биопульсом"],["Стерильный хаос", "+25 здоровья"],["Грант на катастрофу", "+10 урона и 10 здоровья"]],
 [["Калибр судьбы", "+7 урона пулемётом"],["Броня на сдачу", "+25 здоровья"],["Последний патрон", "+10 урона и 10 здоровья"]],
 [["Комиссия", "+7 урона контрактом"],["Деловая хватка", "+25 здоровья"],["Чёрная бухгалтерия", "+10 урона и 10 здоровья"]]
]
const DIALOG_CHOICES := [
 ["Помочь выжившим: отдать 15 кредитов",1,-15,"Шваб: «Милосердие? В бухгалтерии это проходит как эксперимент»."],
 ["Потребовать дань: получить 25 кредитов",-1,25,"Шваб: «Отлично. Теперь даже конец света работает по подписке»."],
 ["Нейтрально: запросить инструкцию",0,0,"Шваб: «Главное — оформите отчёт. Апокалипсис без отчёта не засчитывается»." ]
]
var karma := 0
var choices_made := 0
var talent_ranks := [[0,0,0],[0,0,0],[0,0,0],[0,0,0]]
var portrait_textures := []
var hero_textures := []
var touch_dir := Vector2i.ZERO
var dialog_box: ConfirmationDialog
var talent_box: AcceptDialog
var story_box: AcceptDialog
var hero_image: TextureRect
var moving_time := 0.0
var facing := Vector2i.DOWN

func _ready() -> void:
 rng.seed = 20261107
 for i in range(4):
  portrait_textures.append(load("res://assets/portrait_%d.png"%i))
  hero_textures.append(load("res://assets/hero_%d.png"%i))
 _make_world()
 _make_ui()
 _load_game()
 queue_redraw()

func _make_world() -> void:
 for y in range(H):
  var row := []
  for x in range(W):
   var wall := x == 0 or y == 0 or x == W-1 or y == H-1
   var road := abs(x-18) <= 2 or abs(y-12) <= 2
   if not wall and not road and rng.randf() < 0.13: wall = true
   row.append(1 if wall else (2 if road else 0))
  tiles.append(row)
 for i in range(32):
  var pos := Vector2i(rng.randi_range(2,W-3),rng.randi_range(2,H-3))
  if _passable(pos) and pos.distance_to(player)>5 and pos.distance_to(Vector2i(18,12))>4:
   enemies.append({"pos":pos,"hp":45+i%5*12,"max_hp":45+i%5*12,"name":["Мародёр","Дрон людей","Пепельный разведчик"][i%3]})
 for i in range(22):
  var pos := Vector2i(rng.randi_range(2,W-3),rng.randi_range(2,H-3))
  if _passable(pos): loot.append(pos)
 for p in [player,Vector2i(18,12),Vector2i(6,6),Vector2i(30,20),Vector2i(28,5)]:
  for yy in range(max(1,p.y-2),min(H-1,p.y+3)):
   for xx in range(max(1,p.x-2),min(W-1,p.x+3)): tiles[yy][xx] = 2

func _passable(p:Vector2i) -> bool:
 return p.x>0 and p.y>0 and p.x<W-1 and p.y<H-1 and tiles[p.y][p.x]!=1

func _make_ui() -> void:
 ui=CanvasLayer.new()
 add_child(ui)
 var root=Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter=Control.MOUSE_FILTER_IGNORE
 ui.add_child(root)
 var side=PanelContainer.new()
 side.position=Vector2(895,5)
 side.custom_minimum_size=Vector2(380,710)
 root.add_child(side)
 var stack=VBoxContainer.new()
 stack.add_theme_constant_override("separation",5)
 side.add_child(stack)
 var header=HBoxContainer.new()
 stack.add_child(header)
 hero_image=TextureRect.new()
 hero_image.custom_minimum_size=Vector2(96,96)
 hero_image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
 hero_image.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
 header.add_child(hero_image)
 var hero_col=VBoxContainer.new()
 header.add_child(hero_col)
 for key in ["title","stats"]:
  var l=Label.new()
  l.add_theme_font_size_override("font_size",16)
  l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
  hero_col.add_child(l)
  labels[key]=l
 for key in ["quest","message"]:
  var l=Label.new()
  l.add_theme_font_size_override("font_size",15)
  l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
  l.custom_minimum_size=Vector2(350,68 if key=="quest" else 95)
  stack.add_child(l)
  labels[key]=l
 stack.add_child(HSeparator.new())
 var heroes=GridContainer.new()
 heroes.columns=4
 stack.add_child(heroes)
 for i in range(4):
  var b=Button.new()
  b.custom_minimum_size=Vector2(85,54)
  b.text=HEROES[i].name
  b.pressed.connect(_choose_hero.bind(i))
  heroes.add_child(b)
 var actions=GridContainer.new()
 actions.columns=3
 stack.add_child(actions)
 for entry in [["⚔ Атака","attack"],["✦ Диалог","talk"],["✚ Лечение","heal"],["🌿 Навыки","tree"],["📖 История","bio"],["💾 Сохранить","save"],["↻ Загрузить","load"],["⚖ Выбор","choices"],["★ Способность","special"]]:
  var b=Button.new()
  b.text=entry[0]
  b.custom_minimum_size=Vector2(115,55)
  b.pressed.connect(_action.bind(entry[1]))
  actions.add_child(b)
 var caption=Label.new()
 caption.text="ANDROID · СЕНСОРНОЕ УПРАВЛЕНИЕ"
 caption.add_theme_font_size_override("font_size",13)
 stack.add_child(caption)
 var pad=Control.new()
 pad.position=Vector2(24,490)
 pad.custom_minimum_size=Vector2(220,220)
 root.add_child(pad)
 for entry in [["▲",Vector2(76,0),Vector2i.UP],["◀",Vector2(0,76),Vector2i.LEFT],["▼",Vector2(76,152),Vector2i.DOWN],["▶",Vector2(152,76),Vector2i.RIGHT]]:
  var b=Button.new()
  b.text=entry[0]
  b.position=entry[1]
  b.custom_minimum_size=Vector2(68,68)
  b.button_down.connect(_touch_down.bind(entry[2]))
  b.button_up.connect(_touch_up)
  pad.add_child(b)
 dialog_box=ConfirmationDialog.new()
 dialog_box.title="Выбор судьбы Улья"
 dialog_box.dialog_text="Кому достанется последний белковый паёк?"
 dialog_box.ok_button_text="Помочь людям"
 dialog_box.add_button("Взять дань",false,"bad")
 dialog_box.add_button("Остаться в стороне",false,"neutral")
 dialog_box.confirmed.connect(_pick_choice.bind(0))
 dialog_box.custom_action.connect(_choice_action)
 root.add_child(dialog_box)
 talent_box=AcceptDialog.new()
 talent_box.title="Древо мутаций"
 root.add_child(talent_box)
 story_box=AcceptDialog.new()
 story_box.title="Личные дела Улья"
 root.add_child(story_box)
 _refresh_ui()

func _touch_down(d:Vector2i) -> void:
 touch_dir=d
func _touch_up() -> void:
 touch_dir=Vector2i.ZERO
func _choice_action(action:StringName) -> void:
 _pick_choice(1 if action=="bad" else 2)
 dialog_box.hide()
func _pick_choice(index:int) -> void:
 var choice=DIALOG_CHOICES[index]
 if credits+int(choice[2])<0:
  log_text="Для доброго дела нужно хотя бы 15 кредитов. Утопия не финансируется сама."
 else:
  karma+=int(choice[1])
  credits+=int(choice[2])
  choices_made+=1
  log_text=str(choice[3])+" Мораль: "+_alignment()
 _refresh_ui()
func _alignment() -> String:
 return "МИЛОСЕРДНЫЙ" if karma>0 else ("БЕСПОЩАДНЫЙ" if karma<0 else "НЕЙТРАЛЬНЫЙ")
func _show_skills() -> void:
 var text="%s — свободных очков: %d\n"%[HEROES[hero].name,points[hero]]
 for i in range(3):
  text+="%d. %s [ранг %d/3] — %s\n"%[i+1,SKILLS[hero][i][0],talent_ranks[hero][i],SKILLS[hero][i][1]]
 text+="\nНажмите на навык ниже, чтобы улучшить его."
 talent_box.dialog_text=text
 for child in talent_box.get_children():
  if child is Button and child.has_meta("talent_button"):child.queue_free()
 for i in range(3):
  var btn=talent_box.add_button(str(i+1)+" · "+SKILLS[hero][i][0],false,"talent_%d"%i)
  btn.set_meta("talent_button",true)
 talent_box.custom_action.connect(_talent_action,CONNECT_ONE_SHOT)
 talent_box.popup_centered(Vector2i(620,400))
func _talent_action(action:StringName) -> void:
 if not str(action).begins_with("talent_"):return
 var i=int(str(action).trim_prefix("talent_"))
 if points[hero]<=0:log_text="Сначала заработай очки навыков."
 elif talent_ranks[hero][i]>=3:log_text="Навык уже максимального ранга."
 else:
  points[hero]-=1
  talent_ranks[hero][i]+=1
  if i==0:power_bonus[hero]+=7
  elif i==1:hp[hero]+=25
  else:
   power_bonus[hero]+=10
   hp[hero]+=10
  log_text="Открыто: "+SKILLS[hero][i][0]
 talent_box.hide()
 _refresh_ui()

func _choose_hero(i:int) -> void:
 hero=i
 log_text="%s выходит вперёд. Способность: %s."%[HEROES[i].name,HEROES[i].skill]
 _refresh_ui()
 queue_redraw()

func _refresh_ui() -> void:
 if labels.is_empty(): return
 labels["title"].text="ЖУКИ НОВОГО МИРА · ANDROID"
 hero_image.texture=portrait_textures[hero]
 labels["stats"].text="%s · Ур. %d · HP %d/%d · Урон %d · Очки %d"%[HEROES[hero].name,levels[hero],hp[hero],HEROES[hero].max_hp+10*(levels[hero]-1),HEROES[hero].power+power_bonus[hero],points[hero]]
 var tasks=["Найти Шваба у центрального терминала (18,12)","Победить 5 противников (%d/5)"%min(5,kills),"Собрать 5 ящиков припасов", "Добраться до передатчика (30,20)","Вернуться к Швабу (18,12)","Протокол Улья завершён! Исследуйте пустоши."]
 labels["quest"].text="ЗАДАНИЕ: "+tasks[min(quest,tasks.size()-1)]+" · Кредиты: %d · Аптечки: %d"%[credits,medkits]
 labels["message"].text=log_text+"\nПуть: "+_alignment()+" · Решений: "+str(choices_made)

func _process(delta:float) -> void:
 cooldown=maxf(0.0,cooldown-delta)
 if touch_dir!=Vector2i.ZERO:
  facing=touch_dir
  _move(touch_dir)
 flash=maxf(0.0,flash-delta)
 visual_player=visual_player.lerp(Vector2(player),minf(1.0,delta*11.0))
 if visual_player.distance_to(Vector2(player))>0.015: walk_clock+=delta*16.0
 else: walk_clock=0.0
 camera_pos=visual_player*CELL+Vector2(CELL/2,CELL/2)-Vector2(FIELD_WIDTH/2.0,360)
 queue_redraw()

func _unhandled_key_input(event:InputEvent) -> void:
 if not event is InputEventKey or not event.pressed or event.echo: return
 var c=event.physical_keycode
 var d=Vector2i.ZERO
 match c:
  KEY_W,KEY_UP:d=Vector2i.UP
  KEY_S,KEY_DOWN:d=Vector2i.DOWN
  KEY_A,KEY_LEFT:d=Vector2i.LEFT
  KEY_D,KEY_RIGHT:d=Vector2i.RIGHT
 if d!=Vector2i.ZERO:
  facing=d
  _move(d)
 elif c==KEY_SPACE: _action("attack")
 elif c==KEY_E: _action("talk")
 elif c==KEY_H: _action("heal")
 elif c==KEY_K: _action("upgrade")
 elif c==KEY_B: _action("bio")
 elif c==KEY_F5: _action("save")
 elif c==KEY_F9: _load_game()
 elif c>=KEY_1 and c<=KEY_4: _choose_hero(c-KEY_1)

func _move(d:Vector2i) -> void:
 if cooldown>0: return
 cooldown=0.095
 var next=player+d
 if not _passable(next):
  log_text="Завал. Здесь не пройти."
 elif _enemy_at(next)>=0:
  _attack(next)
 else:
  player=next
  var idx=loot.find(player)
  if idx>=0:
   loot.remove_at(idx)
   credits+=12
   if rng.randf()<0.4: medkits+=1
   log_text="Найдены припасы: +12 кредитов."
   if quest==2 and 22-loot.size()>=5:
    quest=3
    log_text="Припасы собраны. Идите к передатчику на юго-востоке."
  if quest==3 and player.distance_to(Vector2i(30,20))<=1:
   quest=4
   log_text="Передатчик активирован. Возвращайтесь к Швабу!"
 _refresh_ui()

func _enemy_at(pos:Vector2i) -> int:
 for i in range(enemies.size()):
  if enemies[i].pos==pos: return i
 return -1

func _attack(target:Vector2i=Vector2i(-1,-1)) -> void:
 if target.x<0:
  for d in [Vector2i.RIGHT,Vector2i.LEFT,Vector2i.UP,Vector2i.DOWN]:
   if _enemy_at(player+d)>=0:
    target=player+d
    break
 var idx=_enemy_at(target)
 if idx<0:
  log_text="В радиусе удара нет противников."
 else:
  var enemy=enemies[idx]
  var damage=HEROES[hero].power+power_bonus[hero]+rng.randi_range(-4,6)
  enemy.hp-=damage
  flash=0.16
  if enemy.hp<=0:
   log_text="%s побеждён. +18 опыта, +8 кредитов."%enemy.name
   enemies.remove_at(idx)
   kills+=1
   credits+=8
   xp[hero]+=18
   if xp[hero]>=levels[hero]*45:
    xp[hero]=0
    levels[hero]+=1
    points[hero]+=1
    hp[hero]=min(hp[hero]+20,HEROES[hero].max_hp+10*(levels[hero]-1))
    log_text+=" Уровень повышен! Нажмите K."
   if quest==1 and kills>=5:
    quest=2
    log_text="Пять угроз устранены. Соберите пять ящиков припасов."
  else:
   enemies[idx]=enemy
   var retaliation=rng.randi_range(3,11)
   hp[hero]=max(0,hp[hero]-retaliation)
   log_text="%s получает %d урона; ответный удар: %d."%[enemy.name,damage,retaliation]
   if hp[hero]==0:
    hp[hero]=HEROES[hero].max_hp
    player=Vector2i(5,5)
    credits=max(0,credits-20)
    log_text="Отряд эвакуировал героя в штаб. Потеряно 20 кредитов."
 _refresh_ui()

func _action(action:String) -> void:
 match action:
  "attack":_attack()
  "talk":
   if player.distance_to(Vector2i(18,12))<=2:
    if quest==0:
     quest=1
     log_text="Шваб: «Эволюция требует дисциплины. Очистите квартал от пяти угроз!»"
    elif quest==4:
     quest=5
     credits+=250
     for i in range(4): points[i]+=2
     log_text="Шваб: «Улей гордится вами!» Награда: 250 кредитов и по 2 очка навыков."
    else: log_text="Шваб: «Работайте, мои дорогие хитиновые специалисты»."
   else: log_text="Шваб находится у центрального терминала (18,12)."
  "heal":
   if medkits>0:
    medkits-=1
    hp[hero]=mini(HEROES[hero].max_hp+10*(levels[hero]-1),hp[hero]+65)
    log_text="%s использует аптечку."%HEROES[hero].name
   else: log_text="Аптечки закончились."
  "upgrade":
   if points[hero]>0:
    points[hero]-=1
    power_bonus[hero]+=5
    log_text="Навык %s улучшен: +5 урона!"%HEROES[hero].skill
   else: log_text="Для улучшения нужен новый уровень."
  "bio":
   story_box.dialog_text=BIO[hero]+"\n\nПуть: "+_alignment()+". Каждый герой помнит жизнь до мутации — и налоговую после."
   story_box.popup_centered(Vector2i(620,330))
   log_text=BIO[hero]
  "save":_save_game()
  "load":_load_game()
  "tree":_show_skills()
  "choices":dialog_box.popup_centered(Vector2i(540,250))
  "special":
   var cost=18
   if credits>=cost:
    credits-=cost
    power_bonus[hero]+=2
    log_text="%s: %s! Усиление +2 урона за %d кредитов."%[HEROES[hero].name,HEROES[hero].skill,cost]
   else:log_text="Способность стоит 18 кредитов."

 _refresh_ui()

func _save_game() -> void:
 var data={"player":[player.x,player.y],"hero":hero,"levels":levels,"xp":xp,"hp":hp,"points":points,"power_bonus":power_bonus,"credits":credits,"medkits":medkits,"kills":kills,"quest":quest,"karma":karma,"choices_made":choices_made,"talent_ranks":talent_ranks,"enemies":[],"loot":[]}
 for e in enemies: data.enemies.append([e.pos.x,e.pos.y,e.hp,e.max_hp,e.name])
 for p in loot: data.loot.append([p.x,p.y])
 var f=FileAccess.open("user://savegame.json",FileAccess.WRITE)
 if f:
  f.store_string(JSON.stringify(data))
  log_text="Игра сохранена."
 else: log_text="Не удалось сохранить игру."
 _refresh_ui()

func _load_game() -> void:
 if not FileAccess.file_exists("user://savegame.json"): return
 var f=FileAccess.open("user://savegame.json",FileAccess.READ)
 if not f: return
 var d=JSON.parse_string(f.get_as_text())
 if not d is Dictionary: return
 player=Vector2i(int(d.player[0]),int(d.player[1]))
 visual_player=Vector2(player)
 hero=int(d.hero)
 levels=d.levels
 xp=d.xp
 hp=d.hp
 points=d.points
 power_bonus=d.power_bonus
 credits=int(d.credits)
 medkits=int(d.medkits)
 kills=int(d.kills)
 quest=int(d.quest)
 karma=int(d.get("karma",0))
 choices_made=int(d.get("choices_made",0))
 talent_ranks=d.get("talent_ranks",[[0,0,0],[0,0,0],[0,0,0],[0,0,0]])
 enemies.clear()
 for e in d.enemies: enemies.append({"pos":Vector2i(int(e[0]),int(e[1])),"hp":int(e[2]),"max_hp":int(e[3]),"name":e[4]})
 loot.clear()
 for p in d.loot: loot.append(Vector2i(int(p[0]),int(p[1])))
 log_text="Сохранение загружено."
 _refresh_ui()

func _draw() -> void:
 var view=get_viewport_rect().size
 draw_rect(Rect2(Vector2.ZERO,view),Color("080d15"))
 for y in range(H):
  for x in range(W):
   var pos=Vector2(x*CELL,y*CELL)-camera_pos
   if pos.x < -CELL or pos.y < -CELL or pos.x > view.x or pos.y > view.y: continue
   var t=tiles[y][x]
   var base=Color("19262b") if t==0 else (Color("28323c") if t==2 else Color("11171d"))
   draw_rect(Rect2(pos,Vector2(CELL-1,CELL-1)),base)
   if t==1:
    draw_rect(Rect2(pos+Vector2(5,6),Vector2(CELL-11,CELL-12)),Color("43515a"))
    draw_line(pos+Vector2(7,12),pos+Vector2(42,34),Color("66717b"),2)
   elif (x*7+y*13)%11==0:
    draw_circle(pos+Vector2(15,35),3,Color("6d5341"))
 for p in loot:
  var center=Vector2(p*CELL)-camera_pos+Vector2(CELL/2,CELL/2)
  draw_rect(Rect2(center-Vector2(10,9),Vector2(20,18)),Color("c2a45e"))
  draw_line(center-Vector2(9,0),center+Vector2(9,0),Color("503e24"),3)
 var terminal=Vector2(18*CELL,12*CELL)-camera_pos+Vector2(CELL/2,CELL/2)
 draw_circle(terminal,23,Color("d9aa57"))
 draw_circle(terminal,17,Color("30272a"))
 draw_string(ThemeDB.fallback_font,terminal+Vector2(-25,-30),"ШВАБ",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("f6cf8b"))
 var tower=Vector2(30*CELL,20*CELL)-camera_pos+Vector2(CELL/2,CELL/2)
 draw_rect(Rect2(tower-Vector2(17,21),Vector2(34,42)),Color("6d7a96"))
 draw_circle(tower,9,Color("70e8f2"))
 for e in enemies:
  var center=Vector2(e.pos*CELL)-camera_pos+Vector2(CELL/2,CELL/2)
  draw_circle(center+Vector2(0,6),19,Color("9a4c53"))
  draw_circle(center+Vector2(0,-7),12,Color("d78078"))
  draw_line(center+Vector2(-12,0),center+Vector2(-23,12),Color("d78078"),4)
  draw_line(center+Vector2(12,0),center+Vector2(23,12),Color("d78078"),4)
  draw_rect(Rect2(center+Vector2(-20,-29),Vector2(40*float(e.hp)/e.max_hp,4)),Color("f65f68"))
 var pc=visual_player*CELL-camera_pos+Vector2(CELL/2,CELL/2)
 draw_ellipse_shadow(pc)
 var moving=visual_player.distance_to(Vector2(player))>0.025
 if moving:moving_time+=get_process_delta_time()*15.0
 var bob=abs(sin(moving_time))*5.0 if moving else sin(Time.get_ticks_msec()/300.0)*1.5
 var sprite=hero_textures[hero]
 var frame=Rect2(Vector2.ZERO,sprite.get_size())
 var size=Vector2(74,84)
 draw_texture_rect_region(sprite,Rect2(pc-Vector2(size.x/2.0,size.y*0.72+bob),size),frame)
 if moving:
  draw_line(pc+Vector2(-13,11),pc+Vector2(-14+sin(moving_time)*7,24),Color("182027"),4)
  draw_line(pc+Vector2(13,11),pc+Vector2(14-sin(moving_time)*7,24),Color("182027"),4)
 draw_arc(pc,27,0,TAU,32,Color("e9cf85"),2)
 if flash>0:draw_circle(pc,35,Color(1,0.75,0.3,flash*1.5))
 draw_rect(Rect2(Vector2(FIELD_WIDTH,0),Vector2(view.x-FIELD_WIDTH,view.y)),Color("0b111c"))
 draw_line(Vector2(FIELD_WIDTH,0),Vector2(FIELD_WIDTH,view.y),Color("b98c52"),3)

func draw_ellipse_shadow(center:Vector2) -> void:
 draw_set_transform(center+Vector2(0,18),0,Vector2(1.0,0.35))
 draw_circle(Vector2.ZERO,23,Color(0,0,0,0.4))
 draw_set_transform(Vector2.ZERO)
